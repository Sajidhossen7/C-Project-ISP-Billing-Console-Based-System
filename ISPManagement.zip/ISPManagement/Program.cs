﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISPManagement
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            try
            {
                new DataAccess();
            }
            catch
            {
            }

            while (true)
            {
                SessionManager.MainForm = null;
                using (var login = new FLogin())
                {
                    var dr = login.ShowDialog();
                    if (dr == DialogResult.OK && SessionManager.MainForm != null)
                    {
                       
                        Application.Run(SessionManager.MainForm);
                    
                        continue;
                    }
                    else
                    {
                     
                        break;
                    }
                }
            }
        }
    }
}
