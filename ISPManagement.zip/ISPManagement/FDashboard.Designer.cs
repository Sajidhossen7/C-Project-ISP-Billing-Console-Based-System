﻿namespace ISPManagement
{
    partial class FDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        # region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelAllAmount = new System.Windows.Forms.Panel();
            this.lblDashboard = new System.Windows.Forms.Label();
            this.lblInactiveCustomerAmmount = new System.Windows.Forms.Label();
            this.lblActiveCustomerAmmount = new System.Windows.Forms.Label();
            this.lblTotalCustomerAmmount = new System.Windows.Forms.Label();
            this.lblThisMonthCollectionAmmount = new System.Windows.Forms.Label();
            this.lblInactiveCustomer = new System.Windows.Forms.Label();
            this.lblActiveCustomer = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblThisMonthCollection = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnlSitebar = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnMonthlyReport = new System.Windows.Forms.Button();
            this.btnplans = new System.Windows.Forms.Button();
            this.btnEmployee = new System.Windows.Forms.Button();
            this.btnInvoice = new System.Windows.Forms.Button();
            this.btnCustomers = new System.Windows.Forms.Button();
            this.lblIspManagmentSystem = new System.Windows.Forms.Label();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.panelAllAmount.SuspendLayout();
            this.pnlSitebar.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelAllAmount
            // 
            this.panelAllAmount.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelAllAmount.BackColor = System.Drawing.Color.Cornsilk;
            this.panelAllAmount.Controls.Add(this.lblDashboard);
            this.panelAllAmount.Controls.Add(this.lblInactiveCustomerAmmount);
            this.panelAllAmount.Controls.Add(this.lblActiveCustomerAmmount);
            this.panelAllAmount.Controls.Add(this.lblTotalCustomerAmmount);
            this.panelAllAmount.Controls.Add(this.lblThisMonthCollectionAmmount);
            this.panelAllAmount.Controls.Add(this.lblInactiveCustomer);
            this.panelAllAmount.Controls.Add(this.lblActiveCustomer);
            this.panelAllAmount.Controls.Add(this.label1);
            this.panelAllAmount.Controls.Add(this.lblThisMonthCollection);
            this.panelAllAmount.Controls.Add(this.panel3);
            this.panelAllAmount.Location = new System.Drawing.Point(194, 0);
            this.panelAllAmount.Name = "panelAllAmount";
            this.panelAllAmount.Size = new System.Drawing.Size(1272, 891);
            this.panelAllAmount.TabIndex = 0;
            // 
            // lblDashboard
            // 
            this.lblDashboard.AutoSize = true;
            this.lblDashboard.Font = new System.Drawing.Font("Perpetua", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDashboard.ForeColor = System.Drawing.Color.Coral;
            this.lblDashboard.Location = new System.Drawing.Point(233, 9);
            this.lblDashboard.Name = "lblDashboard";
            this.lblDashboard.Size = new System.Drawing.Size(179, 40);
            this.lblDashboard.TabIndex = 9;
            this.lblDashboard.Text = "Dashboard";
            // 
            // lblInactiveCustomerAmmount
            // 
            this.lblInactiveCustomerAmmount.AutoSize = true;
            this.lblInactiveCustomerAmmount.BackColor = System.Drawing.Color.Red;
            this.lblInactiveCustomerAmmount.Font = new System.Drawing.Font("Perpetua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInactiveCustomerAmmount.Location = new System.Drawing.Point(143, 224);
            this.lblInactiveCustomerAmmount.Name = "lblInactiveCustomerAmmount";
            this.lblInactiveCustomerAmmount.Size = new System.Drawing.Size(13, 15);
            this.lblInactiveCustomerAmmount.TabIndex = 8;
            this.lblInactiveCustomerAmmount.Text = "0";
            // 
            // lblActiveCustomerAmmount
            // 
            this.lblActiveCustomerAmmount.AutoSize = true;
            this.lblActiveCustomerAmmount.BackColor = System.Drawing.Color.Green;
            this.lblActiveCustomerAmmount.Font = new System.Drawing.Font("Perpetua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActiveCustomerAmmount.Location = new System.Drawing.Point(134, 184);
            this.lblActiveCustomerAmmount.Name = "lblActiveCustomerAmmount";
            this.lblActiveCustomerAmmount.Size = new System.Drawing.Size(13, 15);
            this.lblActiveCustomerAmmount.TabIndex = 7;
            this.lblActiveCustomerAmmount.Text = "0";
            // 
            // lblTotalCustomerAmmount
            // 
            this.lblTotalCustomerAmmount.AutoSize = true;
            this.lblTotalCustomerAmmount.BackColor = System.Drawing.Color.DimGray;
            this.lblTotalCustomerAmmount.Font = new System.Drawing.Font("Perpetua", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCustomerAmmount.Location = new System.Drawing.Point(234, 128);
            this.lblTotalCustomerAmmount.Name = "lblTotalCustomerAmmount";
            this.lblTotalCustomerAmmount.Size = new System.Drawing.Size(26, 31);
            this.lblTotalCustomerAmmount.TabIndex = 6;
            this.lblTotalCustomerAmmount.Text = "0";
            // 
            // lblThisMonthCollectionAmmount
            // 
            this.lblThisMonthCollectionAmmount.AutoSize = true;
            this.lblThisMonthCollectionAmmount.BackColor = System.Drawing.Color.DarkCyan;
            this.lblThisMonthCollectionAmmount.Font = new System.Drawing.Font("Perpetua", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThisMonthCollectionAmmount.Location = new System.Drawing.Point(316, 72);
            this.lblThisMonthCollectionAmmount.Name = "lblThisMonthCollectionAmmount";
            this.lblThisMonthCollectionAmmount.Size = new System.Drawing.Size(26, 31);
            this.lblThisMonthCollectionAmmount.TabIndex = 5;
            this.lblThisMonthCollectionAmmount.Text = "0";
            // 
            // lblInactiveCustomer
            // 
            this.lblInactiveCustomer.AutoSize = true;
            this.lblInactiveCustomer.BackColor = System.Drawing.Color.Red;
            this.lblInactiveCustomer.Font = new System.Drawing.Font("Perpetua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInactiveCustomer.Location = new System.Drawing.Point(24, 224);
            this.lblInactiveCustomer.Name = "lblInactiveCustomer";
            this.lblInactiveCustomer.Size = new System.Drawing.Size(113, 15);
            this.lblInactiveCustomer.TabIndex = 4;
            this.lblInactiveCustomer.Text = "Inactive Customer :";
            // 
            // lblActiveCustomer
            // 
            this.lblActiveCustomer.AutoSize = true;
            this.lblActiveCustomer.BackColor = System.Drawing.Color.Green;
            this.lblActiveCustomer.Font = new System.Drawing.Font("Perpetua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActiveCustomer.Location = new System.Drawing.Point(24, 184);
            this.lblActiveCustomer.Name = "lblActiveCustomer";
            this.lblActiveCustomer.Size = new System.Drawing.Size(104, 15);
            this.lblActiveCustomer.TabIndex = 3;
            this.lblActiveCustomer.Text = "Active Customer :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkGray;
            this.label1.Font = new System.Drawing.Font("Perpetua", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Total Customer :";
            // 
            // lblThisMonthCollection
            // 
            this.lblThisMonthCollection.AutoSize = true;
            this.lblThisMonthCollection.BackColor = System.Drawing.Color.DarkCyan;
            this.lblThisMonthCollection.Font = new System.Drawing.Font("Perpetua", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThisMonthCollection.Location = new System.Drawing.Point(24, 72);
            this.lblThisMonthCollection.Name = "lblThisMonthCollection";
            this.lblThisMonthCollection.Size = new System.Drawing.Size(286, 31);
            this.lblThisMonthCollection.TabIndex = 1;
            this.lblThisMonthCollection.Text = "This Month Collection :";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.DarkGray;
            this.panel3.Location = new System.Drawing.Point(0, 263);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1582, 930);
            this.panel3.TabIndex = 0;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // pnlSitebar
            // 
            this.pnlSitebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnlSitebar.Controls.Add(this.btnLogout);
            this.pnlSitebar.Controls.Add(this.btnMonthlyReport);
            this.pnlSitebar.Controls.Add(this.btnplans);
            this.pnlSitebar.Controls.Add(this.btnEmployee);
            this.pnlSitebar.Controls.Add(this.btnInvoice);
            this.pnlSitebar.Controls.Add(this.btnCustomers);
            this.pnlSitebar.Controls.Add(this.lblIspManagmentSystem);
            this.pnlSitebar.Controls.Add(this.btnDashboard);
            this.pnlSitebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSitebar.Location = new System.Drawing.Point(0, 0);
            this.pnlSitebar.Name = "pnlSitebar";
            this.pnlSitebar.Size = new System.Drawing.Size(200, 653);
            this.pnlSitebar.TabIndex = 1;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLogout.Font = new System.Drawing.Font("Perpetua", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(112, 523);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnMonthlyReport
            // 
            this.btnMonthlyReport.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMonthlyReport.Location = new System.Drawing.Point(32, 371);
            this.btnMonthlyReport.Name = "btnMonthlyReport";
            this.btnMonthlyReport.Size = new System.Drawing.Size(124, 27);
            this.btnMonthlyReport.TabIndex = 6;
            this.btnMonthlyReport.Text = "Monthly Report";
            this.btnMonthlyReport.UseVisualStyleBackColor = true;
            // 
            // btnplans
            // 
            this.btnplans.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnplans.Location = new System.Drawing.Point(32, 258);
            this.btnplans.Name = "btnplans";
            this.btnplans.Size = new System.Drawing.Size(124, 27);
            this.btnplans.TabIndex = 5;
            this.btnplans.Text = "Plans";
            this.btnplans.UseVisualStyleBackColor = true;
            // 
            // btnEmployee
            // 
            this.btnEmployee.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployee.Location = new System.Drawing.Point(32, 311);
            this.btnEmployee.Name = "btnEmployee";
            this.btnEmployee.Size = new System.Drawing.Size(124, 27);
            this.btnEmployee.TabIndex = 4;
            this.btnEmployee.Text = "Employees";
            this.btnEmployee.UseVisualStyleBackColor = true;
            // 
            // btnInvoice
            // 
            this.btnInvoice.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvoice.Location = new System.Drawing.Point(32, 202);
            this.btnInvoice.Name = "btnInvoice";
            this.btnInvoice.Size = new System.Drawing.Size(124, 27);
            this.btnInvoice.TabIndex = 3;
            this.btnInvoice.Text = "Invoice";
            this.btnInvoice.UseVisualStyleBackColor = true;
            // 
            // btnCustomers
            // 
            this.btnCustomers.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomers.Location = new System.Drawing.Point(32, 145);
            this.btnCustomers.Name = "btnCustomers";
            this.btnCustomers.Size = new System.Drawing.Size(124, 27);
            this.btnCustomers.TabIndex = 2;
            this.btnCustomers.Text = "Customers";
            this.btnCustomers.UseVisualStyleBackColor = true;
            this.btnCustomers.Click += new System.EventHandler(this.btnCustomers_Click);
            // 
            // lblIspManagmentSystem
            // 
            this.lblIspManagmentSystem.AutoSize = true;
            this.lblIspManagmentSystem.Font = new System.Drawing.Font("Perpetua", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIspManagmentSystem.ForeColor = System.Drawing.Color.White;
            this.lblIspManagmentSystem.Location = new System.Drawing.Point(12, 9);
            this.lblIspManagmentSystem.Name = "lblIspManagmentSystem";
            this.lblIspManagmentSystem.Size = new System.Drawing.Size(176, 18);
            this.lblIspManagmentSystem.TabIndex = 1;
            this.lblIspManagmentSystem.Text = "ISP Management System";
            // 
            // btnDashboard
            // 
            this.btnDashboard.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.Location = new System.Drawing.Point(32, 86);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(124, 27);
            this.btnDashboard.TabIndex = 0;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = true;
            // 
            // FDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1460, 653);
            this.Controls.Add(this.pnlSitebar);
            this.Controls.Add(this.panelAllAmount);
            this.Name = "FDashboard";
            this.Text = "Dashboard";
            this.panelAllAmount.ResumeLayout(false);
            this.panelAllAmount.PerformLayout();
            this.pnlSitebar.ResumeLayout(false);
            this.pnlSitebar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelAllAmount;
        private System.Windows.Forms.Label lblThisMonthCollection;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel pnlSitebar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblActiveCustomer;
        private System.Windows.Forms.Label lblInactiveCustomer;
        private System.Windows.Forms.Label lblThisMonthCollectionAmmount;
        private System.Windows.Forms.Label lblTotalCustomerAmmount;
        private System.Windows.Forms.Label lblInactiveCustomerAmmount;
        private System.Windows.Forms.Label lblActiveCustomerAmmount;
        private System.Windows.Forms.Label lblDashboard;
        private System.Windows.Forms.Label lblIspManagmentSystem;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnMonthlyReport;
        private System.Windows.Forms.Button btnplans;
        private System.Windows.Forms.Button btnEmployee;
        private System.Windows.Forms.Button btnInvoice;
        private System.Windows.Forms.Button btnCustomers;
    }
}