using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISPManagement
{
    public partial class FPlans : Form
    {
        public FPlans()
        {
            InitializeComponent();
            try
            {
                NavigationHandler.WireUp(this, btnDashboard, btnCustomers, btnInvoice, btnEmployee, btnplans, btnMonthlyReport, btnLogout);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error initializing sidebar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FPlans_Load(object sender, EventArgs e)
        {
     
            this.plansTableAdapter.Fill(this.iSPManagementDataSet6.Plans);

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) ||
                string.IsNullOrWhiteSpace(txtSpeedMbps.Text) ||
                string.IsNullOrWhiteSpace(txtprice.Text) ||
                string.IsNullOrWhiteSpace(cmbBillingCycle.Text))
            {
                MessageBox.Show("Please fill all required fields.");
                return;
            }

            try
            {
                DataAccess da = new DataAccess();

           
                DataTable dt = da.ExecuteQueryTable(
                    "SELECT ISNULL(MAX(id), 0) AS LastID FROM Plans"
                );

                int lastID = Convert.ToInt32(dt.Rows[0]["LastID"]);

             
                int newID = lastID + 1;

                string name = txtName.Text.Trim();
                string speed = txtSpeedMbps.Text.Trim();
                string price = txtprice.Text.Trim();
                string billingCycle = cmbBillingCycle.Text.Trim();

                string sql = "INSERT INTO Plans " +
                             "(id, name, speed_mbps, price, billing_cycle) " +
                             "VALUES (" +
                             newID + ", '" +
                             name.Replace("'", "''") + "', " +
                             speed + ", " +
                             price + ", '" +
                             billingCycle.Replace("'", "''") + "')";

                int count = da.ExecuteDMLQuery(sql);

                if (count > 0)
                {
                    MessageBox.Show("Plan has been saved.");

                    plansGridView.DataSource =
                        da.ExecuteQueryTable("SELECT * FROM Plans");

               
                }
                else
                {
                    MessageBox.Show("Plan hasn't been saved.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

       

        private void plansGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = plansGridView.Rows[e.RowIndex];


                txtID.Text = row.Cells[0].Value?.ToString();
                txtName.Text = row.Cells[1].Value?.ToString();
                txtSpeedMbps.Text = row.Cells[2].Value?.ToString();
                txtprice.Text = row.Cells[3].Value?.ToString();
                cmbBillingCycle.Text = row.Cells[4].Value?.ToString();
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Please double-click a plan first.");
                return;
            }

            DialogResult result = MessageBox.Show(
                "Are you sure you want to delete this plan?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.No)
                return;

            try
            {
                DataAccess da = new DataAccess();

                string id = txtID.Text.Trim();

                string sql = "DELETE FROM Plans WHERE id = " + id;

                int count = da.ExecuteDMLQuery(sql);

                if (count > 0)
                {
                    MessageBox.Show("Plan has been deleted.");

                  
                    plansGridView.DataSource =
                        da.ExecuteQueryTable("SELECT * FROM Plans");

                  
               
                }
                else
                {
                    MessageBox.Show("Plan hasn't been deleted.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtName.Text = "";
            txtSpeedMbps.Text = "";
            txtprice.Text = "";
            cmbBillingCycle.SelectedIndex = -1;

            plansGridView.ClearSelection();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            FLogin login = new FLogin();

            login.Show();

            this.Hide();
        }
    }
}
