using System;
using System.Data;
using System.Windows.Forms;

namespace ISPManagement
{
    public partial class FEmployeeDashboard : Form
    {
        public FEmployeeDashboard()
        {
            InitializeComponent();
            try
            {
                // Hook up the shared navigation logic
                NavigationHandler.WireUpEmployee(this, btnDashboard, btnCustomers, btnInvoice, btnplans, btnLogout);

                // Load dashboard data when the form loads
                this.Load += FEmployeeDashboard_Load;

                // Also refresh data if the user clicks the Dashboard button again
                if (btnDashboard != null)
                {
                    btnDashboard.Click += BtnDashboard_Click;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error initializing employee dashboard: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FEmployeeDashboard_Load(object sender, EventArgs e)
        {
            LoadDashboardData();
        }

        private void BtnDashboard_Click(object sender, EventArgs e)
        {
            LoadDashboardData(); // Refresh the data when Dashboard button is clicked
        }

        private void LoadDashboardData()
        {
            try
            {
                DataAccess da = new DataAccess();

                // 1. Total Customers (From Customer table)
                string qTotal = "SELECT COUNT(*) FROM Customer";
                DataTable dtTotal = da.ExecuteQueryTable(qTotal);
                if (dtTotal.Rows.Count > 0 && dtTotal.Rows[0][0] != DBNull.Value)
                {
                    lblTotalCustomerAmmount.Text = dtTotal.Rows[0][0].ToString();
                }
                else
                {
                    lblTotalCustomerAmmount.Text = "0";
                }

                // 2. Active Customers (From Customer table)
                string qActive = "SELECT COUNT(*) FROM Customer WHERE status = 'active'";
                DataTable dtActive = da.ExecuteQueryTable(qActive);
                if (dtActive.Rows.Count > 0 && dtActive.Rows[0][0] != DBNull.Value)
                {
                    lblActiveCustomerAmmount.Text = dtActive.Rows[0][0].ToString();
                }
                else
                {
                    lblActiveCustomerAmmount.Text = "0";
                }

                // 3. Inactive Customers (From Customer table)
                string qInactive = "SELECT COUNT(*) FROM Customer WHERE status = 'inactive'";
                DataTable dtInactive = da.ExecuteQueryTable(qInactive);
                if (dtInactive.Rows.Count > 0 && dtInactive.Rows[0][0] != DBNull.Value)
                {
                    lblInactiveCustomerAmmount.Text = dtInactive.Rows[0][0].ToString();
                }
                else
                {
                    lblInactiveCustomerAmmount.Text = "0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading dashboard data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
