﻿namespace ISPManagement
{
    partial class FEmployeeDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCustomers = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.lblDashboard = new System.Windows.Forms.Label();
            this.lblInactiveCustomerAmmount = new System.Windows.Forms.Label();
            this.lblActiveCustomerAmmount = new System.Windows.Forms.Label();
            this.lblTotalCustomerAmmount = new System.Windows.Forms.Label();
            this.lblInactiveCustomer = new System.Windows.Forms.Label();
            this.lblActiveCustomer = new System.Windows.Forms.Label();
            this.btnplans = new System.Windows.Forms.Button();
            this.btnInvoice = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblIspManagmentSystem = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCustomers
            // 
            this.btnCustomers.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomers.Location = new System.Drawing.Point(32, 145);
            this.btnCustomers.Name = "btnCustomers";
            this.btnCustomers.Size = new System.Drawing.Size(124, 27);
            this.btnCustomers.TabIndex = 2;
            this.btnCustomers.Text = "Customers";
            this.btnCustomers.UseVisualStyleBackColor = true;
            // 
            // btnDashboard
            // 
            this.btnDashboard.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.Location = new System.Drawing.Point(32, 86);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(124, 27);
            this.btnDashboard.TabIndex = 0;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = true;
            // 
            // lblDashboard
            // 
            this.lblDashboard.AutoSize = true;
            this.lblDashboard.Font = new System.Drawing.Font("Perpetua", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDashboard.ForeColor = System.Drawing.Color.Coral;
            this.lblDashboard.Location = new System.Drawing.Point(233, 9);
            this.lblDashboard.Name = "lblDashboard";
            this.lblDashboard.Size = new System.Drawing.Size(179, 40);
            this.lblDashboard.TabIndex = 9;
            this.lblDashboard.Text = "Dashboard";
            // 
            // lblInactiveCustomerAmmount
            // 
            this.lblInactiveCustomerAmmount.AutoSize = true;
            this.lblInactiveCustomerAmmount.BackColor = System.Drawing.Color.Red;
            this.lblInactiveCustomerAmmount.Font = new System.Drawing.Font("Perpetua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInactiveCustomerAmmount.Location = new System.Drawing.Point(143, 135);
            this.lblInactiveCustomerAmmount.Name = "lblInactiveCustomerAmmount";
            this.lblInactiveCustomerAmmount.Size = new System.Drawing.Size(13, 15);
            this.lblInactiveCustomerAmmount.TabIndex = 8;
            this.lblInactiveCustomerAmmount.Text = "0";
            // 
            // lblActiveCustomerAmmount
            // 
            this.lblActiveCustomerAmmount.AutoSize = true;
            this.lblActiveCustomerAmmount.BackColor = System.Drawing.Color.Green;
            this.lblActiveCustomerAmmount.Font = new System.Drawing.Font("Perpetua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActiveCustomerAmmount.Location = new System.Drawing.Point(134, 104);
            this.lblActiveCustomerAmmount.Name = "lblActiveCustomerAmmount";
            this.lblActiveCustomerAmmount.Size = new System.Drawing.Size(13, 15);
            this.lblActiveCustomerAmmount.TabIndex = 7;
            this.lblActiveCustomerAmmount.Text = "0";
            // 
            // lblTotalCustomerAmmount
            // 
            this.lblTotalCustomerAmmount.AutoSize = true;
            this.lblTotalCustomerAmmount.BackColor = System.Drawing.Color.DimGray;
            this.lblTotalCustomerAmmount.Font = new System.Drawing.Font("Perpetua", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCustomerAmmount.Location = new System.Drawing.Point(234, 55);
            this.lblTotalCustomerAmmount.Name = "lblTotalCustomerAmmount";
            this.lblTotalCustomerAmmount.Size = new System.Drawing.Size(26, 31);
            this.lblTotalCustomerAmmount.TabIndex = 6;
            this.lblTotalCustomerAmmount.Text = "0";
            // 
            // lblInactiveCustomer
            // 
            this.lblInactiveCustomer.AutoSize = true;
            this.lblInactiveCustomer.BackColor = System.Drawing.Color.Red;
            this.lblInactiveCustomer.Font = new System.Drawing.Font("Perpetua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInactiveCustomer.Location = new System.Drawing.Point(24, 135);
            this.lblInactiveCustomer.Name = "lblInactiveCustomer";
            this.lblInactiveCustomer.Size = new System.Drawing.Size(113, 15);
            this.lblInactiveCustomer.TabIndex = 4;
            this.lblInactiveCustomer.Text = "Inactive Customer :";
            // 
            // lblActiveCustomer
            // 
            this.lblActiveCustomer.AutoSize = true;
            this.lblActiveCustomer.BackColor = System.Drawing.Color.Green;
            this.lblActiveCustomer.Font = new System.Drawing.Font("Perpetua", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActiveCustomer.Location = new System.Drawing.Point(24, 104);
            this.lblActiveCustomer.Name = "lblActiveCustomer";
            this.lblActiveCustomer.Size = new System.Drawing.Size(104, 15);
            this.lblActiveCustomer.TabIndex = 3;
            this.lblActiveCustomer.Text = "Active Customer :";
            // 
            // btnplans
            // 
            this.btnplans.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnplans.Location = new System.Drawing.Point(32, 258);
            this.btnplans.Name = "btnplans";
            this.btnplans.Size = new System.Drawing.Size(124, 27);
            this.btnplans.TabIndex = 5;
            this.btnplans.Text = "Plans";
            this.btnplans.UseVisualStyleBackColor = true;
            // 
            // btnInvoice
            // 
            this.btnInvoice.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvoice.Location = new System.Drawing.Point(32, 202);
            this.btnInvoice.Name = "btnInvoice";
            this.btnInvoice.Size = new System.Drawing.Size(124, 27);
            this.btnInvoice.TabIndex = 3;
            this.btnInvoice.Text = "Invoice";
            this.btnInvoice.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkGray;
            this.label1.Font = new System.Drawing.Font("Perpetua", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Total Customer :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.btnLogout);
            this.panel2.Controls.Add(this.btnplans);
            this.panel2.Controls.Add(this.btnInvoice);
            this.panel2.Controls.Add(this.btnCustomers);
            this.panel2.Controls.Add(this.lblIspManagmentSystem);
            this.panel2.Controls.Add(this.btnDashboard);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 556);
            this.panel2.TabIndex = 3;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLogout.Font = new System.Drawing.Font("Perpetua", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(112, 523);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            // 
            // lblIspManagmentSystem
            // 
            this.lblIspManagmentSystem.AutoSize = true;
            this.lblIspManagmentSystem.Font = new System.Drawing.Font("Perpetua", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIspManagmentSystem.ForeColor = System.Drawing.Color.White;
            this.lblIspManagmentSystem.Location = new System.Drawing.Point(12, 9);
            this.lblIspManagmentSystem.Name = "lblIspManagmentSystem";
            this.lblIspManagmentSystem.Size = new System.Drawing.Size(176, 18);
            this.lblIspManagmentSystem.TabIndex = 1;
            this.lblIspManagmentSystem.Text = "ISP Management System";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Cornsilk;
            this.panel1.Controls.Add(this.lblDashboard);
            this.panel1.Controls.Add(this.lblInactiveCustomerAmmount);
            this.panel1.Controls.Add(this.lblActiveCustomerAmmount);
            this.panel1.Controls.Add(this.lblTotalCustomerAmmount);
            this.panel1.Controls.Add(this.lblInactiveCustomer);
            this.panel1.Controls.Add(this.lblActiveCustomer);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(194, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(908, 556);
            this.panel1.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkGray;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 246);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(908, 310);
            this.panel3.TabIndex = 0;
            // 
            // FEmployeeDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1102, 556);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FEmployeeDashboard";
            this.Text = "FEmployeeDashboard";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCustomers;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Label lblDashboard;
        private System.Windows.Forms.Label lblInactiveCustomerAmmount;
        private System.Windows.Forms.Label lblActiveCustomerAmmount;
        private System.Windows.Forms.Label lblTotalCustomerAmmount;
        private System.Windows.Forms.Label lblInactiveCustomer;
        private System.Windows.Forms.Label lblActiveCustomer;
        private System.Windows.Forms.Button btnplans;
        private System.Windows.Forms.Button btnInvoice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label lblIspManagmentSystem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
    }
}