using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISPManagement
{
    public partial class FInvoice : Form
    {
        private decimal baseAmount = 0m;
        private decimal lastFinalAmount = 0m;
        public FInvoice()
        {
            InitializeComponent();
            try
            {
                NavigationHandler.WireUp(this, btnDashboard, btnCustomers, btnInvoice, btnEmployee, btnplans, btnMonthlyReport, btnLogout);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error initializing sidebar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cmbMonth.Text) ||
                string.IsNullOrWhiteSpace(textamount.Text))
            {
                MessageBox.Show("Please fill all required fields.");
                return;
            }

            try
            {
                DataAccess da = new DataAccess();
                string sql = "";
                string amt = baseAmount.ToString();
                string disc = string.IsNullOrWhiteSpace(textDiscount.Text) ? "0" : textDiscount.Text.Trim();
                string tx = string.IsNullOrWhiteSpace(textTax.Text) ? "0" : textTax.Text.Trim();

                if (string.IsNullOrWhiteSpace(txtID.Text))
                {
                    MessageBox.Show("Customer ID is required.");
                    return;
                }

                string custId = txtID.Text.Trim();
                var custCheckDt = da.ExecuteQueryTable("SELECT * FROM Customer WHERE id = '" + custId + "';");
                if (custCheckDt == null || custCheckDt.Rows.Count == 0)
                {
                    MessageBox.Show("Customer not exist.");
                    return;
                }

                int monthsToAdd = 0;
                int.TryParse(cmbMonth.Text, out monthsToAdd);

                decimal finalAmt = 0m;
                if (!decimal.TryParse(this.textamount.Text, out finalAmt))
                {
                    decimal bd = baseAmount;
                    decimal d = 0m; decimal t = 0m;
                    decimal.TryParse(disc, out d);
                    decimal.TryParse(tx, out t);
                    finalAmt = bd - d + t;
                }

                sql = "INSERT INTO Invoice " +
                      "(customer_id, month, amount, note, payment_date, discount, tax, bulling_date, total_bill) " +
                      "VALUES ('" + custId + "', '" +
                      cmbMonth.Text + "', " +
                      amt + ", '" +
                      txtNote.Text.Replace("'", "''") + "', GETDATE(), " +
                      disc + ", " +
                      tx + ", DATEADD(month, " + monthsToAdd + ", GETDATE()), " + finalAmt.ToString() + ")";

                int count = da.ExecuteDMLQuery(sql);

                if (count > 0)
                {
                    MessageBox.Show("Data has been saved");

                    invoiceGridView1.DataSource =
                        da.ExecuteQueryTable("SELECT * FROM Invoice");

                    RecalculateGridTotals();

                    try
                    {
                        da.ExecuteDMLQuery("UPDATE Customer SET expire_date = DATEADD(month, " + monthsToAdd + ", GETDATE()) WHERE id = '" + custId + "';");

                        foreach (Form f in Application.OpenForms)
                        {
                            if (f is FCustomers fc)
                            {
                                try { fc.RefreshCustomerGrid(); } catch { }
                            }
                        }
                    }
                    catch { }

                    btnClear_Click(sender, e);
                }
                else
                {
                    MessageBox.Show("Data hasn't been saved");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.invoiceGridView1.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to delete.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }

                var id = this.invoiceGridView1.CurrentRow.Cells[0].Value.ToString();
                var title = this.invoiceGridView1.CurrentRow.Cells[1].Value.ToString();

                DialogResult res = MessageBox.Show("Are you sure to remove " + title + "?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (res == DialogResult.No)
                    return;

                DataAccess da = new DataAccess();
                string sql = "DELETE FROM Invoice WHERE id = '" + id + "';";
                int count = da.ExecuteDMLQuery(sql);

                if (count == 1)
                    MessageBox.Show(title.ToUpper() + " has been removed from the list");
                else
                    MessageBox.Show("Data hasn't been deleted");

                this.invoiceGridView1.DataSource = da.ExecuteQueryTable("SELECT * FROM Invoice");
                this.ClearAll();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured: " + exc.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearAll();
            //this.AutoIdGenerate();
        }


        private void ClearAll()
        {
            this.txtID.Clear();
            this.txtNote.Clear();

            this.txtID.Clear();
             this.cmbMonth.SelectedIndex = -1;
            this.textamount.Clear();
            this.txtNote.Clear();
            this.textDiscount.Clear();
            this.textTax.Text = "";
            this.txtSearchForNewBill.Text = "";
            this.invoiceGridView1.ClearSelection();

        }


        private void FInvoice_Load(object sender, EventArgs e)
        {
            this.invoiceTableAdapter2.Fill(this.iSPManagementDataSet10.Invoice);

            this.invoiceTableAdapter1.Fill(this.iSPManagementDataSet5.Invoice);



        }

        private void cmbMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Please enter Customer ID first.");
                cmbMonth.SelectedIndex = -1;
                return;
            }

            int months = 0;
            if (!int.TryParse(cmbMonth.Text, out months) || months <= 0)
            {
                return;
            }

            try
            {
                DataAccess da = new DataAccess();
                string custId = txtID.Text.Trim();
                string q = "SELECT p.price FROM Customer c JOIN Plans p ON c.plan_id = p.id WHERE c.id = '" + custId + "';";
                var dt = da.ExecuteQueryTable(q);
                if (dt == null || dt.Rows.Count == 0)
                {
                    MessageBox.Show("Customer or plan not found.");
                    return;
                }

                decimal price = 0m;
                decimal.TryParse(dt.Rows[0]["price"].ToString(), out price);

                baseAmount = price * months;
                this.textamount.Text = baseAmount.ToString();

                RecalculateAmount();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error calculating amount: " + ex.Message);
            }
        }

        private void RecalculateGridTotals()
        {
            try
            {
                foreach (DataGridViewRow row in invoiceGridView1.Rows)
                {
                    if (row.IsNewRow) continue;

                    decimal amount = 0m;
                    decimal discount = 0m;
                    decimal tax = 0m;

                    var cellAmount = row.Cells[3].Value; 
                    var cellDiscount = row.Cells[6].Value;
                    var cellTax = row.Cells[7].Value; 

                    decimal.TryParse(cellAmount?.ToString(), out amount);
                    decimal.TryParse(cellDiscount?.ToString(), out discount);
                    decimal.TryParse(cellTax?.ToString(), out tax);

                    decimal total = amount - discount + tax;
                    if (total < 0) total = 0;

                    if (invoiceGridView1.Columns.Contains("total_bill"))
                    {
                        row.Cells["total_bill"].Value = total;
                    }
                    else
                    {
                        row.Cells[row.Cells.Count - 1].Value = total;
                    }
                }
            }
            catch { }
        }

        private void textDiscount_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textDiscount.Text))
            {
                RecalculateAmount();
                return;
            }

            int discVal;
            if (!int.TryParse(textDiscount.Text.Trim(), out discVal))
            {
                MessageBox.Show("Discount must be an integer.");
                textDiscount.Text = "";
                return;
            }

            RecalculateAmount();
        }

        private void textTax_TextChanged(object sender, EventArgs e)
        {
            RecalculateAmount();
        }

        private void RecalculateAmount()
        {
            decimal discount = 0m;
            decimal tax = 0m;

            if (!string.IsNullOrWhiteSpace(textDiscount.Text))
            {
                int tmp;
                if (int.TryParse(textDiscount.Text.Trim(), out tmp))
                    discount = tmp;
            }

            if (!string.IsNullOrWhiteSpace(textTax.Text))
            {
                decimal tmpd;
                if (decimal.TryParse(textTax.Text.Trim(), out tmpd))
                    tax = tmpd;
            }

            decimal final = baseAmount - discount + tax;
            if (final < 0) final = 0;
            this.textamount.Text = final.ToString();
            lastFinalAmount = final;
        }

     
         private void invoiceGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.invoiceGridView1.Rows[e.RowIndex];

                
                this.txtID.Text = row.Cells[0].Value?.ToString();
                this.cmbMonth.Text = row.Cells[2].Value?.ToString();
                this.textamount.Text = row.Cells[3].Value?.ToString();

                this.txtNote.Text = row.Cells[4].Value?.ToString();

                this.textDiscount.Text = row.Cells[6].Value?.ToString();

                 this.textTax.Text = row.Cells[7].Value?.ToString();
            }
        }

        private void invoiceGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.invoiceGridView1.Rows[e.RowIndex];

                this.txtID.Text = row.Cells[0].Value?.ToString();
                this.cmbMonth.Text = row.Cells[2].Value?.ToString();
                this.textamount.Text = row.Cells[3].Value?.ToString();
                this.txtNote.Text = row.Cells[4].Value?.ToString();
                this.textDiscount.Text = row.Cells[6].Value?.ToString();
                this.textTax.Text = row.Cells[7].Value?.ToString();
            }
        }

        private void btnSearchInvoice_Click(object sender, EventArgs e)
        {
      

            try
            {
                string searchText = this.txtSearchForNewBill.Text.Trim();

                string sql = "select * from Invoice " +
                             "where id like '%" + searchText + "%' " +
                             "or customer_id like '%" + searchText + "%' " +
                             "or month like '%" + searchText + "%' " +
                             "or amount like '%" + searchText + "%' " +
                             "or note like '%" + searchText + "%';";

                DataAccess da = new DataAccess();
                DataTable dt = da.ExecuteQueryTable(sql);

                this.invoiceGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            FLogin login = new FLogin();

            login.Show();

            this.Hide();
        }
    }
}
