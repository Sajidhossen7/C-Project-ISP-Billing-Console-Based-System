using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISPManagement
{
    public partial class FMonthlyReport : Form
    {
        public FMonthlyReport()
        {
            InitializeComponent();
            try
            {
                NavigationHandler.WireUp(this, btnDashboard, btnCustomers, btnInvoice, btnEmployee, btnplans, btnMonthlyReport, btnLogout);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error initializing sidebar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FMonthlyReport_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'iSPManagementDataSet8.MonthlyReport' table. You can move, or remove it, as needed.
            this.monthlyReportTableAdapter.Fill(this.iSPManagementDataSet8.MonthlyReport);

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            FLogin login = new FLogin();

            login.Show();

            this.Hide();
        }
    }
}
