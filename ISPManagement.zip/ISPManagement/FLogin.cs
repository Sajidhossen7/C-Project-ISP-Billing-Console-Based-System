using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISPManagement
{
    public partial class FLogin : Form
    {
        public DataAccess da = new DataAccess();

        public FLogin()
        {
            
            InitializeComponent();
            
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                string email = this.txtUserName.Text.Trim();
                string password = this.txtBoxPassword.Text.Trim();

                if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show(
                        "Please enter both email and password.",
                        "Validation",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }

             
                email = email.Replace("'", "''");
                password = password.Replace("'", "''");

                string sql = @"SELECT *
                   FROM [User]
                   WHERE email = '" + email + @"'
                   AND password = '" + password + "'";

                DataTable dt = da.ExecuteQueryTable(sql);

                if (dt.Rows.Count == 1)
                {
                    string role = dt.Rows[0]["role"].ToString().Trim();

                    MessageBox.Show(
                        "Login Successful",
                        "Success",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );

                    if (role.Equals("admin", StringComparison.OrdinalIgnoreCase))
                    {
                        FDashboard adminDashboard = new FDashboard();

                        NavigationHandler.SetMainForm(adminDashboard);
                        SessionManager.MainForm = adminDashboard;

                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    else if (role.Equals("employee", StringComparison.OrdinalIgnoreCase))
                    {
                        FEmployeeDashboard employeeDashboard = new FEmployeeDashboard();

                        NavigationHandler.SetMainForm(employeeDashboard);
                        SessionManager.MainForm = employeeDashboard;

                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show(
                            "Unknown role: " + role,
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                        );
                    }
                }
                else
                {
                    MessageBox.Show(
                        "Invalid Email or Password",
                        "Login Failed",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "An error occurred:\n" + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBoxShow_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShow.Checked)
            {
                // Show password text
                txtBoxPassword.PasswordChar = '\0';
            }
            else
            {
                // Hide password
                txtBoxPassword.PasswordChar = '*';
            }

        }
    }
}
