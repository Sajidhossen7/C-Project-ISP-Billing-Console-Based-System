using System;
using System.Windows.Forms;

namespace ISPManagement
{
    public static class NavigationHandler
    {
        // Track the application's initial main form so we never close it (only hide)
        private static Form MainForm;

        public static void SetMainForm(Form main)
        {
            if (main == null) return;
            MainForm = main;
        }
        public static void WireUp(Form currentForm, 
            Button btnDashboard, 
            Button btnCustomers, 
            Button btnInvoice, 
            Button btnEmployee, 
            Button btnPlans, 
            Button btnMonthlyReport, 
            Button btnLogout)
        {
            // remember the first form we wire up as the main startup form
            if (MainForm == null && currentForm != null)
                MainForm = currentForm;
            if (btnDashboard != null)
                btnDashboard.Click += (s, e) => NavigateTo(currentForm, new FDashboard());
            
            if (btnCustomers != null)
                btnCustomers.Click += (s, e) => NavigateTo(currentForm, new FCustomers());
            
            if (btnInvoice != null)
                btnInvoice.Click += (s, e) => NavigateTo(currentForm, new FInvoice());
            
            if (btnEmployee != null)
                btnEmployee.Click += (s, e) => NavigateTo(currentForm, new FEmployee());
            
            if (btnPlans != null)
                btnPlans.Click += (s, e) => NavigateTo(currentForm, new FPlans());
            
            if (btnMonthlyReport != null)
                btnMonthlyReport.Click += (s, e) => NavigateTo(currentForm, new FMonthlyReport());
            
            if (btnLogout != null)
                btnLogout.Click += (s, e) => { try { currentForm.Close(); } catch { } };
        }

        public static void WireUpEmployee(Form currentForm, 
            Button btnDashboard, 
            Button btnCustomers, 
            Button btnInvoice, 
            Button btnPlans, 
            Button btnLogout)
        {
            if (MainForm == null && currentForm != null)
                MainForm = currentForm;
            if (btnDashboard != null)
                btnDashboard.Click += (s, e) => NavigateTo(currentForm, new FEmployeeDashboard());
            
            if (btnCustomers != null)
                btnCustomers.Click += (s, e) => NavigateTo(currentForm, new FCustomers());
            
            if (btnInvoice != null)
                btnInvoice.Click += (s, e) => NavigateTo(currentForm, new FInvoice());
            
            if (btnPlans != null)
                btnPlans.Click += (s, e) => NavigateTo(currentForm, new FPlans());
            
            if (btnLogout != null)
                btnLogout.Click += (s, e) => { try { currentForm.Close(); } catch { } };
        }

        private static void NavigateTo(Form currentForm, Form targetForm)
        {
            try
            {
                // If target is the main startup form type, show existing MainForm and close others
                if (MainForm != null && targetForm.GetType() == MainForm.GetType())
                {
                    // Close all other non-main forms
                    var forms = new System.Collections.Generic.List<Form>();
                    foreach (Form f in Application.OpenForms)
                        forms.Add(f);

                    foreach (var f in forms)
                    {
                        if (f == MainForm) continue;
                        try { f.Close(); } catch { }
                    }

                    MainForm.Show();
                    try { targetForm.Dispose(); } catch { }
                    return;
                }

                // For non-main targets: close any existing non-main forms (so only main + one other exist)
                var openFormsList = new System.Collections.Generic.List<Form>();
                foreach (Form f in Application.OpenForms)
                    openFormsList.Add(f);

                foreach (var f in openFormsList)
                {
                    if (MainForm != null && f == MainForm) continue;
                    // If a form of the same type as target already exists, bring it to front and dispose the new one
                    if (f.GetType() == targetForm.GetType())
                    {
                        if (f.WindowState == FormWindowState.Minimized) f.WindowState = FormWindowState.Normal;
                        f.BringToFront();
                        f.Activate();
                        try { targetForm.Dispose(); } catch { }
                        return;
                    }
                    try { f.Close(); } catch { }
                }

                // Show the new target form (MainForm remains open in background)
                targetForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Navigation Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
