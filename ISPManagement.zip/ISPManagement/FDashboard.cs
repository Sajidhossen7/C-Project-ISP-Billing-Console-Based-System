using System;
using System.Data;
using System.Windows.Forms;

namespace ISPManagement
{
    public partial class FDashboard : Form
    {
        public FDashboard()
        {
            InitializeComponent();
            try
            {
                NavigationHandler.WireUp(this, btnDashboard, btnCustomers, btnInvoice, btnEmployee, btnplans, btnMonthlyReport, btnLogout);

                // Load dashboard data when the form loads
                this.Load += FDashboard_Load;

                if (btnDashboard != null)
                {
                    btnDashboard.Click += BtnDashboard_Click;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error initializing dashboard: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FDashboard_Load(object sender, EventArgs e)
        {
            LoadDashboardData();
        }

        private void BtnDashboard_Click(object sender, EventArgs e)
        {
            LoadDashboardData(); // Refresh the data when Dashboard button is clicked
        }

        private void LoadDashboardData()
        {
            try
            {
                DataAccess da = new DataAccess();

             
                string qCollection = @"
                    SELECT SUM(amount) 
                    FROM Invoice 
                    WHERE MONTH(payment_date) = MONTH(GETDATE()) 
                      AND YEAR(payment_date) = YEAR(GETDATE())";
                DataTable dtCollection = da.ExecuteQueryTable(qCollection);


                if (dtCollection.Rows.Count > 0 && dtCollection.Rows[0][0] != DBNull.Value)
                {
                    lblThisMonthCollectionAmmount.Text = dtCollection.Rows[0][0].ToString();
                }
                else
                {
                    lblThisMonthCollectionAmmount.Text = "0";
                }

                // 2. Total Customers (From Customer table)
                string qTotal = "SELECT COUNT(*) AS Total FROM Customer";

                DataSet ds = da.ExecuteQuery(qTotal);

                int totalCustomer = Convert.ToInt32(ds.Tables[0].Rows[0]["Total"]); 
                if (totalCustomer > 0)
                {
                    lblTotalCustomerAmmount.Text = totalCustomer.ToString();
                }
                else
                {
                    lblTotalCustomerAmmount.Text = "0";
                }

                // 3. Active Customers (From Customer table)
                string qActive = "SELECT COUNT(*) AS Active FROM Customer WHERE status = 'active'";
                DataSet dsActive = da.ExecuteQuery(qActive);
                if (dsActive.Tables[0].Rows.Count > 0 && dsActive.Tables[0].Rows[0]["Active"] != DBNull.Value)
                {
                    lblActiveCustomerAmmount.Text = dsActive.Tables[0].Rows[0]["Active"].ToString();
                }
                else
                {
                    lblActiveCustomerAmmount.Text = "0";
                }

                // 4. Inactive Customers (From Customer table)
                string qInactive = "SELECT COUNT(*) AS Inactive FROM Customer WHERE status = 'inactive'";
                DataSet dsInactive = da.ExecuteQuery(qInactive);
                if (dsInactive.Tables[0].Rows.Count > 0 && dsInactive.Tables[0].Rows[0]["Inactive"] != DBNull.Value)
                {
                    lblInactiveCustomerAmmount.Text = dsInactive.Tables[0].Rows[0]["Inactive"].ToString();
                }
                else
                {
                    lblInactiveCustomerAmmount.Text = "0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading dashboard data: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            FLogin login = new FLogin();

            login.Show();

            this.Hide();
        }
    }
}
