using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISPManagement
{
    public partial class FEmployee : Form
    {
        public FEmployee()
        {
            InitializeComponent();
            try
            {
                NavigationHandler.WireUp(this, btnDashboard, btnCustomers, btnInvoice, btnEmployee, btnplans, btnMonthlyReport, btnLogout);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error initializing sidebar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FEmployee_Load(object sender, EventArgs e)
        {
        
            this.userTableAdapter.Fill(this.iSPManagementDataSet7.User);

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            FLogin login = new FLogin();

            login.Show();

            this.Hide();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
           
            if (string.IsNullOrWhiteSpace(txtTitle.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(txtIncome.Text) ||
                string.IsNullOrWhiteSpace(cmbrole.Text))
            {
                MessageBox.Show("Please fill all required fields.");
                return;
            }
            string email = textBox2.Text.Trim();
            string phone = textBox1.Text.Trim();

            
            if (!System.Text.RegularExpressions.Regex.IsMatch(
                email,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Please enter a valid email address.");
                textBox2.Focus();
                return;
            }

          
            if (!System.Text.RegularExpressions.Regex.IsMatch(
                phone,
                @"^01[3-9]\d{8}$"))
            {
                MessageBox.Show("Please enter a valid 11-digit Bangladesh phone number.\nExample: 01712345678");
                textBox1.Focus();
                return;
            }




            try
            {
                DataAccess da = new DataAccess();

              
                DataTable dt = da.ExecuteQueryTable(
                    "SELECT ISNULL(MAX(id), 0) AS LastID FROM [User]"
                );

                int lastID = Convert.ToInt32(dt.Rows[0]["LastID"]);

               
                int newID = lastID + 1;

                string name = txtTitle.Text.Trim();
                 email = textBox2.Text.Trim();
                 phone = textBox1.Text.Trim();
                string password = txtIncome.Text.Trim();
                string role = cmbrole.Text.Trim();

                string sql = "INSERT INTO [User] " +
                             "(id, name, email, phone, password, role) " +
                             "VALUES (" +
                             newID + ", '" +
                             name.Replace("'", "''") + "', '" +
                             email.Replace("'", "''") + "', '" +
                             phone.Replace("'", "''") + "', '" +
                             password.Replace("'", "''") + "', '" +
                             role.Replace("'", "''") + "')";

                int count = da.ExecuteDMLQuery(sql);

                if (count > 0)
                {
                    MessageBox.Show("Employee has been saved.");

                 
                    customerGridView1.DataSource =
                        da.ExecuteQueryTable("SELECT * FROM [User]");

                  
                    btnClear_Click(sender, e);
                }
                else
                {
                    MessageBox.Show("Employee hasn't been saved.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                MessageBox.Show("Please double-click a user row first.");
                return;
            }

            DialogResult result = MessageBox.Show(
                "Are you sure you want to delete this employee?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.No)
                return;

            try
            {
                DataAccess da = new DataAccess();

                string id = txtID.Text.Trim();

                string sql = "DELETE FROM [User] WHERE id = " + id;

                int count = da.ExecuteDMLQuery(sql);

                if (count > 0)
                {
                    MessageBox.Show("Employee has been deleted.");

                   
                    customerGridView1.DataSource =
                        da.ExecuteQueryTable("SELECT * FROM [User]");

                   
                    btnClear_Click(sender, e);
                }
                else
                {
                    MessageBox.Show("Employee hasn't been deleted.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtTitle.Text = "";
            textBox2.Text = "";
            textBox1.Text = "";
            txtIncome.Text = "";
            cmbrole.SelectedIndex = -1;

            customerGridView1.ClearSelection();
        }

        private void customerGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = customerGridView1.Rows[e.RowIndex];

                txtID.Text = row.Cells[0].Value?.ToString();
                txtTitle.Text = row.Cells[1].Value?.ToString();
                textBox2.Text = row.Cells[2].Value?.ToString();
                textBox1.Text = row.Cells[3].Value?.ToString();
                txtIncome.Text = row.Cells[4].Value?.ToString();
                cmbrole.Text = row.Cells[5].Value?.ToString();
            }
        }

        private void txtBoxSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DataAccess da = new DataAccess();

                string searchText = txtBoxSearch.Text.Trim();

                if (string.IsNullOrEmpty(searchText))
                {
                    customerGridView1.DataSource =
                        da.ExecuteQueryTable("SELECT * FROM [User]");
                    return;
                }

                string sql = "SELECT * FROM [User] " +
                             "WHERE CAST(id AS VARCHAR) LIKE '%" + searchText + "%' " +
                             "OR name LIKE '%" + searchText + "%' " +
                             "OR email LIKE '%" + searchText + "%' " +
                             "OR phone LIKE '%" + searchText + "%' " +
                             "OR role LIKE '%" + searchText + "%'";

                customerGridView1.DataSource =
                    da.ExecuteQueryTable(sql);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
