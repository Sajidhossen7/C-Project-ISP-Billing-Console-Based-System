using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ISPManagement
{
    public partial class FCustomers : Form
    { public DataAccess Da ;
        public FCustomers()
        {
             Da = new DataAccess();
            InitializeComponent();
            try
            {
                NavigationHandler.WireUp(this, btnDashboard, btnCustomers, btnInvoice, btnEmployee, btnplans, btnMonthlyReport, btnLogout);
                this.customerTableAdapter1.Fill(this.iSPManagementDataSet1.Customer);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error initializing sidebar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Customers_Load(object sender, EventArgs e)
        {
            
            this.customerTableAdapter1.Fill(this.iSPManagementDataSet1.Customer);

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
        }

        private void customerGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private string GetLastId()
        {
            string query = "select top 1 id from Customer order by id desc;";
            var dt = this.Da.ExecuteQueryTable(query);

          
            if (dt == null || dt.Rows.Count == 0)
            {
                return "1";
            }

            return dt.Rows[0]["id"].ToString();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int id =int.Parse( this.GetLastId())+1;
            string name = this.txtName.Text.Trim();
            string username = "U-" + id;
            string password = this.txtPassword.Text.Trim();
            string email = this.textEmail.Text.Trim();
            string phone = this.textPhone.Text.Trim();
            string address = this.texAddress.Text.Trim();
            string selectedPlan = this.cmbPlans.Text.Trim();
            string Status = this.comboStatus.Text.Trim();

             int planId = 0;
            switch (selectedPlan)
            {
                case "Basic": planId = 1; break;
                case "Standard": planId = 2; break;
                case "Premium": planId = 3; break;
                case "Business": planId = 4; break;
                case "Ultra": planId = 5; break;
            }

          
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(address) || planId == 0 || string.IsNullOrEmpty(Status))
            {
                MessageBox.Show("Please fill all the empty fields");
                return;
            }

           
            if (phone.Length != 11)
            {
                MessageBox.Show("Phone number must be exactly 11 characters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

         
            if (!email.Contains("@"))
            {
                MessageBox.Show("Please enter a valid email containing '@'.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {

                var sql = "insert into Customer(id , name, username, password, email, phone, address, plan_id, status, payment_date, expire_date) values('" + id + "','" + name + "', '" + username + "', '" + password + "', '" + email + "', '" + phone + "', '" + address + "', " + planId + ", '" + Status + "', GETDATE(), GETDATE())";

                DataAccess da = new DataAccess();
                var count = da.ExecuteDMLQuery(sql);

                if (count == 1) { 
                    MessageBox.Show("Data has been added");
                this.customerGridView1.DataSource = this.Da.ExecuteQueryTable("select * from Customer");
                }
                else
                    MessageBox.Show("Data hasn't been added");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.customerGridView1.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to delete.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }

                var id = this.customerGridView1.CurrentRow.Cells[0].Value.ToString();
                var title = this.customerGridView1.CurrentRow.Cells[1].Value.ToString();

                DialogResult res = MessageBox.Show("Are you sure to remove " + title + "?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (res == DialogResult.No)
                    return;

                var sql = "delete from Movie where Id = '" + id + "';";
                var count = this.Da.ExecuteDMLQuery(sql);

                if (count == 1)
                    MessageBox.Show(title.ToUpper() + " has been removed from the list");
                else
                    MessageBox.Show("Data hasn't been deleted");

                this.customerGridView1.DataSource = this.Da.ExecuteQueryTable("select * from Customer");
                this.ClearAll();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured: " + exc.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearAll();
            //this.AutoIdGenerate();
        }


        private void ClearAll()
        {
            this.txtID.Clear();
            this.txtName.Clear();
            this.txtUsername.Clear();
            this.txtPassword.Clear();
            this.textPhone.Clear();
            this.textEmail.Clear();
            this.texAddress.Clear();
            this.comboStatus.Text = "";
            this.cmbPlans.SelectedIndex = -1;

            this.txtBoxSearch.Text = "";
            this.comboStatus.SelectedIndex = -1;
            this.customerGridView1.ClearSelection();
            
        }



            

        private void customerGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                this.txtID.Text = this.customerGridView1.CurrentRow.Cells[0].Value.ToString();
                this.txtName.Text = this.customerGridView1.CurrentRow.Cells[1].Value.ToString();
                this.txtUsername.Text = this.customerGridView1.CurrentRow.Cells[2].Value.ToString();
                this.txtPassword.Text = this.customerGridView1.CurrentRow.Cells[3].Value.ToString();
                this.textPhone.Text = this.customerGridView1.CurrentRow.Cells[4].Value.ToString();
                this.textEmail.Text = this.customerGridView1.CurrentRow.Cells[5].Value.ToString();
                this.texAddress.Text = this.customerGridView1.CurrentRow.Cells[6].Value.ToString();
                this.comboStatus.Text = this.customerGridView1.CurrentRow.Cells[7].Value.ToString();

                string planIdStr = this.customerGridView1.CurrentRow.Cells[9].Value.ToString();
                switch (planIdStr)
                {
                    case "1": this.cmbPlans.Text = "Basic"; break;
                    case "2": this.cmbPlans.Text = "Standard"; break;
                    case "3": this.cmbPlans.Text = "Premium"; break;
                    case "4": this.cmbPlans.Text = "Business"; break;
                    case "5": this.cmbPlans.Text = "Ultra"; break;
                    default: this.cmbPlans.SelectedIndex = -1; break;
                }
            }

        }

        public void RefreshCustomerGrid()
        {
            try
            {
                this.customerGridView1.DataSource = this.Da.ExecuteQueryTable("select * from Customer");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error refreshing customer grid: " + ex.Message);
            }
        }

        
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                var sql = "select * from Customer where name like '%" + this.txtBoxSearch.Text + "%' or id like '%" + this.txtBoxSearch.Text + "%' or username like '%" + this.txtBoxSearch.Text + "%' or phone like '%" + this.txtBoxSearch.Text + "%';";
                DataAccess da = new DataAccess();
                var dt = da.ExecuteQueryTable(sql);
                this.customerGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void txtBoxSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                var sql = "select * from Customer where name like '%" + this.txtBoxSearch.Text + "%' or id like '%" + this.txtBoxSearch.Text + "%' or username like '%" + this.txtBoxSearch.Text + "%' or phone like '%" + this.txtBoxSearch.Text + "%';";
                DataAccess da = new DataAccess();
                var dt = da.ExecuteQueryTable(sql);
                this.customerGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
