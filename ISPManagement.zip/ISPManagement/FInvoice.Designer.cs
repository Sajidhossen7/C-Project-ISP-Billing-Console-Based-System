﻿namespace ISPManagement
{
    partial class FInvoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnMonthlyReport = new System.Windows.Forms.Button();
            this.btnplans = new System.Windows.Forms.Button();
            this.btnEmployee = new System.Windows.Forms.Button();
            this.btnInvoice = new System.Windows.Forms.Button();
            this.btnCustomers = new System.Windows.Forms.Button();
            this.lblIspManagmentSystem = new System.Windows.Forms.Label();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textTax = new System.Windows.Forms.TextBox();
            this.textDiscount = new System.Windows.Forms.TextBox();
            this.textamount = new System.Windows.Forms.TextBox();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.lblSearchByAll = new System.Windows.Forms.Label();
            this.btnSearchInvoice = new System.Windows.Forms.Button();
            this.txtSearchForNewBill = new System.Windows.Forms.TextBox();
            this.lblNote = new System.Windows.Forms.Label();
            this.lblInvoice = new System.Windows.Forms.Label();
            this.cmbMonth = new System.Windows.Forms.ComboBox();
            this.lblMonth = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.lblId = new System.Windows.Forms.Label();
            this.invoiceGridView1 = new System.Windows.Forms.DataGridView();
            this.invoiceBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.iSPManagementDataSet5 = new ISPManagement.ISPManagementDataSet5();
            this.invoiceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iSPManagementDataSet4 = new ISPManagement.ISPManagementDataSet4();
            this.invoiceTableAdapter = new ISPManagement.ISPManagementDataSet4TableAdapters.InvoiceTableAdapter();
            this.invoiceTableAdapter1 = new ISPManagement.ISPManagementDataSet5TableAdapters.InvoiceTableAdapter();
            this.iSPManagementDataSet10 = new ISPManagement.ISPManagementDataSet10();
            this.invoiceBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.invoiceTableAdapter2 = new ISPManagement.ISPManagementDataSet10TableAdapters.InvoiceTableAdapter();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customer_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.month = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payment_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bulling_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total_bill = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSPManagementDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSPManagementDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSPManagementDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.btnLogout);
            this.panel2.Controls.Add(this.btnMonthlyReport);
            this.panel2.Controls.Add(this.btnplans);
            this.panel2.Controls.Add(this.btnEmployee);
            this.panel2.Controls.Add(this.btnInvoice);
            this.panel2.Controls.Add(this.btnCustomers);
            this.panel2.Controls.Add(this.lblIspManagmentSystem);
            this.panel2.Controls.Add(this.btnDashboard);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(204, 640);
            this.panel2.TabIndex = 5;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLogout.Font = new System.Drawing.Font("Perpetua", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(120, 526);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnMonthlyReport
            // 
            this.btnMonthlyReport.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMonthlyReport.Location = new System.Drawing.Point(32, 371);
            this.btnMonthlyReport.Name = "btnMonthlyReport";
            this.btnMonthlyReport.Size = new System.Drawing.Size(124, 27);
            this.btnMonthlyReport.TabIndex = 6;
            this.btnMonthlyReport.Text = "Monthly Report";
            this.btnMonthlyReport.UseVisualStyleBackColor = true;
            // 
            // btnplans
            // 
            this.btnplans.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnplans.Location = new System.Drawing.Point(32, 258);
            this.btnplans.Name = "btnplans";
            this.btnplans.Size = new System.Drawing.Size(124, 27);
            this.btnplans.TabIndex = 5;
            this.btnplans.Text = "Plans";
            this.btnplans.UseVisualStyleBackColor = true;
            // 
            // btnEmployee
            // 
            this.btnEmployee.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployee.Location = new System.Drawing.Point(32, 311);
            this.btnEmployee.Name = "btnEmployee";
            this.btnEmployee.Size = new System.Drawing.Size(124, 27);
            this.btnEmployee.TabIndex = 4;
            this.btnEmployee.Text = "Employees";
            this.btnEmployee.UseVisualStyleBackColor = true;
            // 
            // btnInvoice
            // 
            this.btnInvoice.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvoice.Location = new System.Drawing.Point(32, 202);
            this.btnInvoice.Name = "btnInvoice";
            this.btnInvoice.Size = new System.Drawing.Size(124, 27);
            this.btnInvoice.TabIndex = 3;
            this.btnInvoice.Text = "Invoice";
            this.btnInvoice.UseVisualStyleBackColor = true;
            // 
            // btnCustomers
            // 
            this.btnCustomers.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomers.Location = new System.Drawing.Point(32, 145);
            this.btnCustomers.Name = "btnCustomers";
            this.btnCustomers.Size = new System.Drawing.Size(124, 27);
            this.btnCustomers.TabIndex = 2;
            this.btnCustomers.Text = "Customers";
            this.btnCustomers.UseVisualStyleBackColor = true;
            // 
            // lblIspManagmentSystem
            // 
            this.lblIspManagmentSystem.AutoSize = true;
            this.lblIspManagmentSystem.Font = new System.Drawing.Font("Perpetua", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIspManagmentSystem.ForeColor = System.Drawing.Color.White;
            this.lblIspManagmentSystem.Location = new System.Drawing.Point(6, 9);
            this.lblIspManagmentSystem.Name = "lblIspManagmentSystem";
            this.lblIspManagmentSystem.Size = new System.Drawing.Size(176, 18);
            this.lblIspManagmentSystem.TabIndex = 1;
            this.lblIspManagmentSystem.Text = "ISP Management System";
            // 
            // btnDashboard
            // 
            this.btnDashboard.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.Location = new System.Drawing.Point(32, 86);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(124, 27);
            this.btnDashboard.TabIndex = 0;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Cornsilk;
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.textTax);
            this.panel3.Controls.Add(this.textDiscount);
            this.panel3.Controls.Add(this.textamount);
            this.panel3.Controls.Add(this.txtNote);
            this.panel3.Controls.Add(this.lblSearchByAll);
            this.panel3.Controls.Add(this.btnSearchInvoice);
            this.panel3.Controls.Add(this.txtSearchForNewBill);
            this.panel3.Controls.Add(this.lblNote);
            this.panel3.Controls.Add(this.lblInvoice);
            this.panel3.Controls.Add(this.cmbMonth);
            this.panel3.Controls.Add(this.lblMonth);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.btnDelete);
            this.panel3.Controls.Add(this.btnClear);
            this.panel3.Controls.Add(this.btnSave);
            this.panel3.Controls.Add(this.lblName);
            this.panel3.Controls.Add(this.txtID);
            this.panel3.Controls.Add(this.lblId);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(204, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1095, 187);
            this.panel3.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 126;
            this.label2.Text = "Discount";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(344, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 16);
            this.label1.TabIndex = 125;
            this.label1.Text = "Tax";
            // 
            // textTax
            // 
            this.textTax.BackColor = System.Drawing.Color.Azure;
            this.textTax.Location = new System.Drawing.Point(398, 37);
            this.textTax.Name = "textTax";
            this.textTax.Size = new System.Drawing.Size(134, 20);
            this.textTax.TabIndex = 124;
            // 
            // textDiscount
            // 
            this.textDiscount.BackColor = System.Drawing.Color.Azure;
            this.textDiscount.Location = new System.Drawing.Point(115, 161);
            this.textDiscount.Name = "textDiscount";
            this.textDiscount.Size = new System.Drawing.Size(134, 20);
            this.textDiscount.TabIndex = 123;
            // 
            // textamount
            // 
            this.textamount.BackColor = System.Drawing.Color.Azure;
            this.textamount.Location = new System.Drawing.Point(115, 58);
            this.textamount.Name = "textamount";
            this.textamount.ReadOnly = true;
            this.textamount.Size = new System.Drawing.Size(134, 20);
            this.textamount.TabIndex = 122;
            // 
            // txtNote
            // 
            this.txtNote.BackColor = System.Drawing.Color.Azure;
            this.txtNote.Location = new System.Drawing.Point(115, 124);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(134, 20);
            this.txtNote.TabIndex = 121;
            // 
            // lblSearchByAll
            // 
            this.lblSearchByAll.AutoSize = true;
            this.lblSearchByAll.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchByAll.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblSearchByAll.Location = new System.Drawing.Point(621, 65);
            this.lblSearchByAll.Name = "lblSearchByAll";
            this.lblSearchByAll.Size = new System.Drawing.Size(85, 13);
            this.lblSearchByAll.TabIndex = 119;
            this.lblSearchByAll.Text = "* Search by  ID ";
            // 
            // btnSearchInvoice
            // 
            this.btnSearchInvoice.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnSearchInvoice.Location = new System.Drawing.Point(758, 34);
            this.btnSearchInvoice.Name = "btnSearchInvoice";
            this.btnSearchInvoice.Size = new System.Drawing.Size(75, 23);
            this.btnSearchInvoice.TabIndex = 118;
            this.btnSearchInvoice.Text = "Search";
            this.btnSearchInvoice.UseVisualStyleBackColor = false;
            this.btnSearchInvoice.Click += new System.EventHandler(this.btnSearchInvoice_Click);
            // 
            // txtSearchForNewBill
            // 
            this.txtSearchForNewBill.BackColor = System.Drawing.Color.Azure;
            this.txtSearchForNewBill.Location = new System.Drawing.Point(602, 37);
            this.txtSearchForNewBill.Name = "txtSearchForNewBill";
            this.txtSearchForNewBill.Size = new System.Drawing.Size(134, 20);
            this.txtSearchForNewBill.TabIndex = 117;
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.Location = new System.Drawing.Point(9, 126);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(37, 16);
            this.lblNote.TabIndex = 116;
            this.lblNote.Text = "Note";
            // 
            // lblInvoice
            // 
            this.lblInvoice.AutoSize = true;
            this.lblInvoice.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblInvoice.Font = new System.Drawing.Font("Perpetua", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvoice.ForeColor = System.Drawing.Color.White;
            this.lblInvoice.Location = new System.Drawing.Point(444, 6);
            this.lblInvoice.Name = "lblInvoice";
            this.lblInvoice.Size = new System.Drawing.Size(60, 18);
            this.lblInvoice.TabIndex = 114;
            this.lblInvoice.Text = "Invoice";
            // 
            // cmbMonth
            // 
            this.cmbMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMonth.FormattingEnabled = true;
            this.cmbMonth.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cmbMonth.Location = new System.Drawing.Point(115, 91);
            this.cmbMonth.Name = "cmbMonth";
            this.cmbMonth.Size = new System.Drawing.Size(134, 21);
            this.cmbMonth.TabIndex = 110;
            this.cmbMonth.SelectedIndexChanged += new System.EventHandler(this.cmbMonth_SelectedIndexChanged);
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonth.Location = new System.Drawing.Point(9, 93);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(48, 16);
            this.lblMonth.TabIndex = 106;
            this.lblMonth.Text = "Month";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label9.Location = new System.Drawing.Point(335, 168);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(135, 13);
            this.label9.TabIndex = 99;
            this.label9.Text = "* Click a row to delete data";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label8.Location = new System.Drawing.Point(335, 151);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(152, 13);
            this.label8.TabIndex = 99;
            this.label8.Text = "* Double click a row to update";
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(927, 34);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(65, 63);
            this.btnDelete.TabIndex = 98;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(927, 112);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(65, 63);
            this.btnClear.TabIndex = 97;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Green;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(856, 34);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(65, 63);
            this.btnSave.TabIndex = 96;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(11, 59);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(58, 16);
            this.lblName.TabIndex = 85;
            this.lblName.Text = "Amount";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(115, 25);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(134, 20);
            this.txtID.TabIndex = 84;
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId.Location = new System.Drawing.Point(9, 28);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(87, 16);
            this.lblId.TabIndex = 83;
            this.lblId.Text = "Customer ID";
            // 
            // invoiceGridView1
            // 
            this.invoiceGridView1.AllowUserToAddRows = false;
            this.invoiceGridView1.AllowUserToDeleteRows = false;
            this.invoiceGridView1.AutoGenerateColumns = false;
            this.invoiceGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invoiceGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.customer_id,
            this.month,
            this.amount,
            this.note,
            this.payment_date,
            this.discount,
            this.tax,
            this.bulling_date,
            this.total_bill});
            this.invoiceGridView1.DataSource = this.invoiceBindingSource2;
            this.invoiceGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.invoiceGridView1.Location = new System.Drawing.Point(204, 187);
            this.invoiceGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.invoiceGridView1.Name = "invoiceGridView1";
            this.invoiceGridView1.ReadOnly = true;
            this.invoiceGridView1.RowHeadersWidth = 51;
            this.invoiceGridView1.RowTemplate.Height = 24;
            this.invoiceGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.invoiceGridView1.Size = new System.Drawing.Size(1095, 453);
            this.invoiceGridView1.TabIndex = 7;
            this.invoiceGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invoiceGridView1_CellContentClick);
            this.invoiceGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invoiceGridView1_CellDoubleClick);
            // 
            // invoiceBindingSource1
            // 
            this.invoiceBindingSource1.DataMember = "Invoice";
            this.invoiceBindingSource1.DataSource = this.iSPManagementDataSet5;
            // 
            // iSPManagementDataSet5
            // 
            this.iSPManagementDataSet5.DataSetName = "ISPManagementDataSet5";
            this.iSPManagementDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // invoiceBindingSource
            // 
            this.invoiceBindingSource.DataMember = "Invoice";
            this.invoiceBindingSource.DataSource = this.iSPManagementDataSet4;
            // 
            // iSPManagementDataSet4
            // 
            this.iSPManagementDataSet4.DataSetName = "ISPManagementDataSet4";
            this.iSPManagementDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // invoiceTableAdapter
            // 
            this.invoiceTableAdapter.ClearBeforeFill = true;
            // 
            // invoiceTableAdapter1
            // 
            this.invoiceTableAdapter1.ClearBeforeFill = true;
            // 
            // iSPManagementDataSet10
            // 
            this.iSPManagementDataSet10.DataSetName = "ISPManagementDataSet10";
            this.iSPManagementDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // invoiceBindingSource2
            // 
            this.invoiceBindingSource2.DataMember = "Invoice";
            this.invoiceBindingSource2.DataSource = this.iSPManagementDataSet10;
            // 
            // invoiceTableAdapter2
            // 
            this.invoiceTableAdapter2.ClearBeforeFill = true;
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "ID";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            this.id.Width = 50;
            // 
            // customer_id
            // 
            this.customer_id.DataPropertyName = "customer_id";
            this.customer_id.HeaderText = "Customer ID";
            this.customer_id.Name = "customer_id";
            this.customer_id.ReadOnly = true;
            this.customer_id.Width = 150;
            // 
            // month
            // 
            this.month.DataPropertyName = "month";
            this.month.HeaderText = "Month\'s";
            this.month.Name = "month";
            this.month.ReadOnly = true;
            this.month.Width = 50;
            // 
            // amount
            // 
            this.amount.DataPropertyName = "amount";
            this.amount.HeaderText = "Amount";
            this.amount.Name = "amount";
            this.amount.ReadOnly = true;
            this.amount.Width = 170;
            // 
            // note
            // 
            this.note.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.note.DataPropertyName = "note";
            this.note.HeaderText = "Note";
            this.note.Name = "note";
            this.note.ReadOnly = true;
            // 
            // payment_date
            // 
            this.payment_date.DataPropertyName = "payment_date";
            this.payment_date.HeaderText = "Payment Date";
            this.payment_date.Name = "payment_date";
            this.payment_date.ReadOnly = true;
            this.payment_date.Width = 120;
            // 
            // discount
            // 
            this.discount.DataPropertyName = "discount";
            this.discount.HeaderText = "Discount Amount";
            this.discount.Name = "discount";
            this.discount.ReadOnly = true;
            this.discount.Width = 150;
            // 
            // tax
            // 
            this.tax.DataPropertyName = "tax";
            this.tax.HeaderText = "Tax Amount";
            this.tax.Name = "tax";
            this.tax.ReadOnly = true;
            this.tax.Width = 150;
            // 
            // bulling_date
            // 
            this.bulling_date.DataPropertyName = "bulling_date";
            this.bulling_date.HeaderText = "Expiary Date";
            this.bulling_date.Name = "bulling_date";
            this.bulling_date.ReadOnly = true;
            this.bulling_date.Width = 120;
            // 
            // total_bill
            // 
            this.total_bill.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.total_bill.DataPropertyName = "total_bill";
            this.total_bill.HeaderText = "Total Bill Amount";
            this.total_bill.Name = "total_bill";
            this.total_bill.ReadOnly = true;
            // 
            // FInvoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1299, 640);
            this.Controls.Add(this.invoiceGridView1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Name = "FInvoice";
            this.Text = "FInvoice";
            this.Load += new System.EventHandler(this.FInvoice_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSPManagementDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSPManagementDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSPManagementDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnMonthlyReport;
        private System.Windows.Forms.Button btnplans;
        private System.Windows.Forms.Button btnEmployee;
        private System.Windows.Forms.Button btnInvoice;
        private System.Windows.Forms.Button btnCustomers;
        private System.Windows.Forms.Label lblIspManagmentSystem;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblInvoice;
        private System.Windows.Forms.ComboBox cmbMonth;
        private System.Windows.Forms.Label lblMonth;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.DataGridView invoiceGridView1;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Button btnSearchInvoice;
        private System.Windows.Forms.TextBox txtSearchForNewBill;
        private System.Windows.Forms.Label lblSearchByAll;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textTax;
        private System.Windows.Forms.TextBox textDiscount;
        private System.Windows.Forms.TextBox textamount;
        private ISPManagementDataSet4 iSPManagementDataSet4;
        private System.Windows.Forms.BindingSource invoiceBindingSource;
        private ISPManagementDataSet4TableAdapters.InvoiceTableAdapter invoiceTableAdapter;
        private ISPManagementDataSet5 iSPManagementDataSet5;
        private System.Windows.Forms.BindingSource invoiceBindingSource1;
        private ISPManagementDataSet5TableAdapters.InvoiceTableAdapter invoiceTableAdapter1;
        private ISPManagementDataSet10 iSPManagementDataSet10;
        private System.Windows.Forms.BindingSource invoiceBindingSource2;
        private ISPManagementDataSet10TableAdapters.InvoiceTableAdapter invoiceTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn customer_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn month;
        private System.Windows.Forms.DataGridViewTextBoxColumn amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn note;
        private System.Windows.Forms.DataGridViewTextBoxColumn payment_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn discount;
        private System.Windows.Forms.DataGridViewTextBoxColumn tax;
        private System.Windows.Forms.DataGridViewTextBoxColumn bulling_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn total_bill;
    }
}