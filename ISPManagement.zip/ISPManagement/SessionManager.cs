using System.Windows.Forms;

namespace ISPManagement
{
    public static class SessionManager
    {
        // Holds the main dashboard form to run as the application's main window after login
        public static Form MainForm { get; set; }
    }
}
