﻿namespace ISPManagement
{
    partial class FCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.customerGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expiredateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.plan_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.iSPManagementDataSet1 = new ISPManagement.ISPManagementDataSet1();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iSPManagementDataSet = new ISPManagement.ISPManagementDataSet();
            this.pnlSitebar = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnMonthlyReport = new System.Windows.Forms.Button();
            this.btnplans = new System.Windows.Forms.Button();
            this.btnEmployee = new System.Windows.Forms.Button();
            this.btnInvoice = new System.Windows.Forms.Button();
            this.btnCustomers = new System.Windows.Forms.Button();
            this.lblIspManagmentSystem = new System.Windows.Forms.Label();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.customerTableAdapter = new ISPManagement.ISPManagementDataSetTableAdapters.CustomerTableAdapter();
            this.plnCustomerdataEdit = new System.Windows.Forms.Panel();
            this.lblAddressNote = new System.Windows.Forms.Label();
            this.lblCustomers = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtBoxSearch = new System.Windows.Forms.TextBox();
            this.lblPlans = new System.Windows.Forms.Label();
            this.cmbPlans = new System.Windows.Forms.ComboBox();
            this.comboStatus = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.texAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.textPhone = new System.Windows.Forms.TextBox();
            this.lblSearchByAll = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblPasswprd = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.lblId = new System.Windows.Forms.Label();
            this.customerTableAdapter1 = new ISPManagement.ISPManagementDataSet1TableAdapters.CustomerTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.customerGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSPManagementDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSPManagementDataSet)).BeginInit();
            this.pnlSitebar.SuspendLayout();
            this.plnCustomerdataEdit.SuspendLayout();
            this.SuspendLayout();
            // 
            // customerGridView1
            // 
            this.customerGridView1.AllowUserToAddRows = false;
            this.customerGridView1.AllowUserToDeleteRows = false;
            this.customerGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.customerGridView1.AutoGenerateColumns = false;
            this.customerGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customerGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.usernameDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn,
            this.phone,
            this.email,
            this.address,
            this.statusDataGridViewTextBoxColumn,
            this.expiredateDataGridViewTextBoxColumn,
            this.plan_id});
            this.customerGridView1.DataSource = this.customerBindingSource1;
            this.customerGridView1.Location = new System.Drawing.Point(192, 192);
            this.customerGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.customerGridView1.Name = "customerGridView1";
            this.customerGridView1.ReadOnly = true;
            this.customerGridView1.RowHeadersWidth = 51;
            this.customerGridView1.RowTemplate.Height = 24;
            this.customerGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.customerGridView1.Size = new System.Drawing.Size(1016, 374);
            this.customerGridView1.TabIndex = 1;
            this.customerGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.customerGridView1_CellContentClick);
            this.customerGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.customerGridView1_CellDoubleClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.FillWeight = 50F;
            this.idDataGridViewTextBoxColumn.HeaderText = "ID";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 50;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "Username";
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            this.usernameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "Password";
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            this.passwordDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // phone
            // 
            this.phone.DataPropertyName = "phone";
            this.phone.HeaderText = "phone";
            this.phone.Name = "phone";
            this.phone.ReadOnly = true;
            // 
            // email
            // 
            this.email.DataPropertyName = "email";
            this.email.HeaderText = "email";
            this.email.Name = "email";
            this.email.ReadOnly = true;
            // 
            // address
            // 
            this.address.DataPropertyName = "address";
            this.address.HeaderText = "address";
            this.address.Name = "address";
            this.address.ReadOnly = true;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // expiredateDataGridViewTextBoxColumn
            // 
            this.expiredateDataGridViewTextBoxColumn.DataPropertyName = "expire_date";
            this.expiredateDataGridViewTextBoxColumn.HeaderText = "Expire Date";
            this.expiredateDataGridViewTextBoxColumn.Name = "expiredateDataGridViewTextBoxColumn";
            this.expiredateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // plan_id
            // 
            this.plan_id.DataPropertyName = "plan_id";
            this.plan_id.HeaderText = "Plan";
            this.plan_id.Name = "plan_id";
            this.plan_id.ReadOnly = true;
            // 
            // customerBindingSource1
            // 
            this.customerBindingSource1.DataMember = "Customer";
            this.customerBindingSource1.DataSource = this.iSPManagementDataSet1;
            // 
            // iSPManagementDataSet1
            // 
            this.iSPManagementDataSet1.DataSetName = "ISPManagementDataSet1";
            this.iSPManagementDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.iSPManagementDataSet;
            // 
            // iSPManagementDataSet
            // 
            this.iSPManagementDataSet.DataSetName = "ISPManagementDataSet";
            this.iSPManagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pnlSitebar
            // 
            this.pnlSitebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnlSitebar.Controls.Add(this.btnLogout);
            this.pnlSitebar.Controls.Add(this.btnMonthlyReport);
            this.pnlSitebar.Controls.Add(this.btnplans);
            this.pnlSitebar.Controls.Add(this.btnEmployee);
            this.pnlSitebar.Controls.Add(this.btnInvoice);
            this.pnlSitebar.Controls.Add(this.btnCustomers);
            this.pnlSitebar.Controls.Add(this.lblIspManagmentSystem);
            this.pnlSitebar.Controls.Add(this.btnDashboard);
            this.pnlSitebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSitebar.Location = new System.Drawing.Point(0, 0);
            this.pnlSitebar.Name = "pnlSitebar";
            this.pnlSitebar.Size = new System.Drawing.Size(204, 568);
            this.pnlSitebar.TabIndex = 2;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLogout.Font = new System.Drawing.Font("Perpetua", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(120, 526);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            // 
            // btnMonthlyReport
            // 
            this.btnMonthlyReport.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMonthlyReport.Location = new System.Drawing.Point(32, 371);
            this.btnMonthlyReport.Name = "btnMonthlyReport";
            this.btnMonthlyReport.Size = new System.Drawing.Size(124, 27);
            this.btnMonthlyReport.TabIndex = 6;
            this.btnMonthlyReport.Text = "Monthly Report";
            this.btnMonthlyReport.UseVisualStyleBackColor = true;
            // 
            // btnplans
            // 
            this.btnplans.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnplans.Location = new System.Drawing.Point(32, 258);
            this.btnplans.Name = "btnplans";
            this.btnplans.Size = new System.Drawing.Size(124, 27);
            this.btnplans.TabIndex = 5;
            this.btnplans.Text = "Plans";
            this.btnplans.UseVisualStyleBackColor = true;
            // 
            // btnEmployee
            // 
            this.btnEmployee.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployee.Location = new System.Drawing.Point(32, 311);
            this.btnEmployee.Name = "btnEmployee";
            this.btnEmployee.Size = new System.Drawing.Size(124, 27);
            this.btnEmployee.TabIndex = 4;
            this.btnEmployee.Text = "Employees";
            this.btnEmployee.UseVisualStyleBackColor = true;
            // 
            // btnInvoice
            // 
            this.btnInvoice.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvoice.Location = new System.Drawing.Point(32, 202);
            this.btnInvoice.Name = "btnInvoice";
            this.btnInvoice.Size = new System.Drawing.Size(124, 27);
            this.btnInvoice.TabIndex = 3;
            this.btnInvoice.Text = "Invoice";
            this.btnInvoice.UseVisualStyleBackColor = true;
            // 
            // btnCustomers
            // 
            this.btnCustomers.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomers.Location = new System.Drawing.Point(32, 145);
            this.btnCustomers.Name = "btnCustomers";
            this.btnCustomers.Size = new System.Drawing.Size(124, 27);
            this.btnCustomers.TabIndex = 2;
            this.btnCustomers.Text = "Customers";
            this.btnCustomers.UseVisualStyleBackColor = true;
            // 
            // lblIspManagmentSystem
            // 
            this.lblIspManagmentSystem.AutoSize = true;
            this.lblIspManagmentSystem.Font = new System.Drawing.Font("Perpetua", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIspManagmentSystem.ForeColor = System.Drawing.Color.White;
            this.lblIspManagmentSystem.Location = new System.Drawing.Point(8, 9);
            this.lblIspManagmentSystem.Name = "lblIspManagmentSystem";
            this.lblIspManagmentSystem.Size = new System.Drawing.Size(176, 18);
            this.lblIspManagmentSystem.TabIndex = 1;
            this.lblIspManagmentSystem.Text = "ISP Management System";
            // 
            // btnDashboard
            // 
            this.btnDashboard.Font = new System.Drawing.Font("Perpetua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.Location = new System.Drawing.Point(32, 86);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(124, 27);
            this.btnDashboard.TabIndex = 0;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.UseVisualStyleBackColor = true;
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // plnCustomerdataEdit
            // 
            this.plnCustomerdataEdit.BackColor = System.Drawing.Color.Cornsilk;
            this.plnCustomerdataEdit.Controls.Add(this.lblAddressNote);
            this.plnCustomerdataEdit.Controls.Add(this.lblCustomers);
            this.plnCustomerdataEdit.Controls.Add(this.btnSearch);
            this.plnCustomerdataEdit.Controls.Add(this.txtBoxSearch);
            this.plnCustomerdataEdit.Controls.Add(this.lblPlans);
            this.plnCustomerdataEdit.Controls.Add(this.cmbPlans);
            this.plnCustomerdataEdit.Controls.Add(this.comboStatus);
            this.plnCustomerdataEdit.Controls.Add(this.lblStatus);
            this.plnCustomerdataEdit.Controls.Add(this.texAddress);
            this.plnCustomerdataEdit.Controls.Add(this.lblAddress);
            this.plnCustomerdataEdit.Controls.Add(this.textEmail);
            this.plnCustomerdataEdit.Controls.Add(this.textPhone);
            this.plnCustomerdataEdit.Controls.Add(this.lblSearchByAll);
            this.plnCustomerdataEdit.Controls.Add(this.label9);
            this.plnCustomerdataEdit.Controls.Add(this.label8);
            this.plnCustomerdataEdit.Controls.Add(this.btnDelete);
            this.plnCustomerdataEdit.Controls.Add(this.btnClear);
            this.plnCustomerdataEdit.Controls.Add(this.btnSave);
            this.plnCustomerdataEdit.Controls.Add(this.lblemail);
            this.plnCustomerdataEdit.Controls.Add(this.lblPhone);
            this.plnCustomerdataEdit.Controls.Add(this.txtPassword);
            this.plnCustomerdataEdit.Controls.Add(this.lblPasswprd);
            this.plnCustomerdataEdit.Controls.Add(this.txtUsername);
            this.plnCustomerdataEdit.Controls.Add(this.lblUsername);
            this.plnCustomerdataEdit.Controls.Add(this.txtName);
            this.plnCustomerdataEdit.Controls.Add(this.lblName);
            this.plnCustomerdataEdit.Controls.Add(this.txtID);
            this.plnCustomerdataEdit.Controls.Add(this.lblId);
            this.plnCustomerdataEdit.Dock = System.Windows.Forms.DockStyle.Top;
            this.plnCustomerdataEdit.Location = new System.Drawing.Point(204, 0);
            this.plnCustomerdataEdit.Name = "plnCustomerdataEdit";
            this.plnCustomerdataEdit.Size = new System.Drawing.Size(1004, 187);
            this.plnCustomerdataEdit.TabIndex = 3;
            // 
            // lblAddressNote
            // 
            this.lblAddressNote.AutoSize = true;
            this.lblAddressNote.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddressNote.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblAddressNote.Location = new System.Drawing.Point(593, 52);
            this.lblAddressNote.Name = "lblAddressNote";
            this.lblAddressNote.Size = new System.Drawing.Size(181, 13);
            this.lblAddressNote.TabIndex = 115;
            this.lblAddressNote.Text = "* House No, Village, Thana, District";
            // 
            // lblCustomers
            // 
            this.lblCustomers.AutoSize = true;
            this.lblCustomers.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblCustomers.Font = new System.Drawing.Font("Perpetua", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomers.ForeColor = System.Drawing.Color.White;
            this.lblCustomers.Location = new System.Drawing.Point(396, 0);
            this.lblCustomers.Name = "lblCustomers";
            this.lblCustomers.Size = new System.Drawing.Size(81, 18);
            this.lblCustomers.TabIndex = 114;
            this.lblCustomers.Text = "Customers";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnSearch.Location = new System.Drawing.Point(727, 161);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 113;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtBoxSearch
            // 
            this.txtBoxSearch.BackColor = System.Drawing.Color.Azure;
            this.txtBoxSearch.Location = new System.Drawing.Point(579, 164);
            this.txtBoxSearch.Name = "txtBoxSearch";
            this.txtBoxSearch.Size = new System.Drawing.Size(134, 20);
            this.txtBoxSearch.TabIndex = 112;
            this.txtBoxSearch.TextChanged += new System.EventHandler(this.txtBoxSearch_TextChanged);
            // 
            // lblPlans
            // 
            this.lblPlans.AutoSize = true;
            this.lblPlans.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlans.Location = new System.Drawing.Point(333, 80);
            this.lblPlans.Name = "lblPlans";
            this.lblPlans.Size = new System.Drawing.Size(40, 16);
            this.lblPlans.TabIndex = 111;
            this.lblPlans.Text = "Plans";
            // 
            // cmbPlans
            // 
            this.cmbPlans.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPlans.FormattingEnabled = true;
            this.cmbPlans.Items.AddRange(new object[] {
            "Basic",
            "Standard",
            "Premium",
            "Business",
            "Ultra"});
            this.cmbPlans.Location = new System.Drawing.Point(453, 73);
            this.cmbPlans.Name = "cmbPlans";
            this.cmbPlans.Size = new System.Drawing.Size(134, 21);
            this.cmbPlans.TabIndex = 110;
            // 
            // comboStatus
            // 
            this.comboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboStatus.FormattingEnabled = true;
            this.comboStatus.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.comboStatus.Location = new System.Drawing.Point(453, 101);
            this.comboStatus.Name = "comboStatus";
            this.comboStatus.Size = new System.Drawing.Size(134, 21);
            this.comboStatus.TabIndex = 109;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(333, 106);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(44, 16);
            this.lblStatus.TabIndex = 108;
            this.lblStatus.Text = "Status";
            // 
            // texAddress
            // 
            this.texAddress.Location = new System.Drawing.Point(453, 48);
            this.texAddress.Name = "texAddress";
            this.texAddress.Size = new System.Drawing.Size(134, 20);
            this.texAddress.TabIndex = 107;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(333, 51);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(58, 16);
            this.lblAddress.TabIndex = 106;
            this.lblAddress.Text = "Address";
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(115, 161);
            this.textEmail.Name = "textEmail";
            this.textEmail.Size = new System.Drawing.Size(134, 20);
            this.textEmail.TabIndex = 103;
            // 
            // textPhone
            // 
            this.textPhone.Location = new System.Drawing.Point(115, 134);
            this.textPhone.Name = "textPhone";
            this.textPhone.Size = new System.Drawing.Size(134, 20);
            this.textPhone.TabIndex = 101;
            // 
            // lblSearchByAll
            // 
            this.lblSearchByAll.AutoSize = true;
            this.lblSearchByAll.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchByAll.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblSearchByAll.Location = new System.Drawing.Point(576, 144);
            this.lblSearchByAll.Name = "lblSearchByAll";
            this.lblSearchByAll.Size = new System.Drawing.Size(212, 13);
            this.lblSearchByAll.TabIndex = 100;
            this.lblSearchByAll.Text = "* Search by Name / ID / Username / Phone";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label9.Location = new System.Drawing.Point(298, 164);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(135, 13);
            this.label9.TabIndex = 99;
            this.label9.Text = "* Click a row to delete data";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Mongolian Baiti", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label8.Location = new System.Drawing.Point(298, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(152, 13);
            this.label8.TabIndex = 99;
            this.label8.Text = "* Double click a row to update";
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(927, 34);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(65, 63);
            this.btnDelete.TabIndex = 98;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(927, 112);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(65, 63);
            this.btnClear.TabIndex = 97;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Green;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(856, 34);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(65, 63);
            this.btnSave.TabIndex = 96;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(12, 162);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(43, 16);
            this.lblemail.TabIndex = 92;
            this.lblemail.Text = "Email";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhone.Location = new System.Drawing.Point(12, 134);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(46, 16);
            this.lblPhone.TabIndex = 91;
            this.lblPhone.Text = "Phone";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(115, 108);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(134, 20);
            this.txtPassword.TabIndex = 90;
            // 
            // lblPasswprd
            // 
            this.lblPasswprd.AutoSize = true;
            this.lblPasswprd.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswprd.Location = new System.Drawing.Point(12, 108);
            this.lblPasswprd.Name = "lblPasswprd";
            this.lblPasswprd.Size = new System.Drawing.Size(66, 16);
            this.lblPasswprd.TabIndex = 89;
            this.lblPasswprd.Text = "Password";
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(115, 82);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.ReadOnly = true;
            this.txtUsername.Size = new System.Drawing.Size(134, 20);
            this.txtUsername.TabIndex = 88;
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.Location = new System.Drawing.Point(12, 82);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(70, 16);
            this.lblUsername.TabIndex = 87;
            this.lblUsername.Text = "Username";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(115, 56);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(134, 20);
            this.txtName.TabIndex = 86;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(12, 56);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(44, 16);
            this.lblName.TabIndex = 85;
            this.lblName.Text = "Name";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(115, 30);
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(134, 20);
            this.txtID.TabIndex = 84;
            this.txtID.TextChanged += new System.EventHandler(this.txtID_TextChanged);
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId.Location = new System.Drawing.Point(12, 30);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(23, 16);
            this.lblId.TabIndex = 83;
            this.lblId.Text = "ID";
            // 
            // customerTableAdapter1
            // 
            this.customerTableAdapter1.ClearBeforeFill = true;
            // 
            // FCustomers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1208, 568);
            this.Controls.Add(this.plnCustomerdataEdit);
            this.Controls.Add(this.pnlSitebar);
            this.Controls.Add(this.customerGridView1);
            this.Name = "FCustomers";
            this.Text = "Customers";
            this.Load += new System.EventHandler(this.Customers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customerGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSPManagementDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iSPManagementDataSet)).EndInit();
            this.pnlSitebar.ResumeLayout(false);
            this.pnlSitebar.PerformLayout();
            this.plnCustomerdataEdit.ResumeLayout(false);
            this.plnCustomerdataEdit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView customerGridView1;
        private System.Windows.Forms.Panel pnlSitebar;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnMonthlyReport;
        private System.Windows.Forms.Button btnplans;
        private System.Windows.Forms.Button btnEmployee;
        private System.Windows.Forms.Button btnInvoice;
        private System.Windows.Forms.Button btnCustomers;
        private System.Windows.Forms.Label lblIspManagmentSystem;
        private System.Windows.Forms.Button btnDashboard;
        private ISPManagementDataSet iSPManagementDataSet;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private ISPManagementDataSetTableAdapters.CustomerTableAdapter customerTableAdapter;
        private System.Windows.Forms.Panel plnCustomerdataEdit;
        private System.Windows.Forms.Label lblSearchByAll;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label lblPasswprd;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox textPhone;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.Label lblPlans;
        private System.Windows.Forms.ComboBox cmbPlans;
        private System.Windows.Forms.ComboBox comboStatus;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TextBox texAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtBoxSearch;
        private System.Windows.Forms.Label lblCustomers;
        private System.Windows.Forms.Label lblAddressNote;
        private ISPManagementDataSet1 iSPManagementDataSet1;
        private System.Windows.Forms.BindingSource customerBindingSource1;
        private ISPManagementDataSet1TableAdapters.CustomerTableAdapter customerTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn email;
        private System.Windows.Forms.DataGridViewTextBoxColumn address;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expiredateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn plan_id;
    }
}